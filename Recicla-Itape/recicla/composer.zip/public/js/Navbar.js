  function openNav() {  
    	document.getElementById("mySidenav").style.left = "0px";
	  }

	/* Set the width of the side navigation to 0 */
	  function closeNav() {
    	document.getElementById("mySidenav").style.left = "-300px";
	  }
    $('.carousel').carousel({

    });