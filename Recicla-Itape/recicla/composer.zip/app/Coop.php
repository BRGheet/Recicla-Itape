<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Coop extends Model
{
    protected $table = "coop";
    public $timestamps = false;
}
