<?php $__env->startSection('cabecalho'); ?>
<div class="container-fluid Content404">
	
</div>
<?php echo $__env->make('site.includes.rodape', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('.site.template.cabecalho', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>