<div class="container-fluid UserContentMain">
	<div class="row">
		<div class="sidebarUser col-md-2 col-md-offset-1">
			<h2>STATUS DA SUA CONTA</h2>
			<div class="col-md-12 userButtons">
				<dl class="pontosUser">
					<dt>Atualmente você tem:</dt>
					<dd><span><?php echo e(Auth::user()->pontos); ?></span><br>
					Pontos Disponíveis.</dd>
				</dl>
				<!-- Botoes conta -->
				<nav class="menu-user-btn">
					<ul>
						<li>
							<a href="/minha_conta">
								MINHA CONTA
							</a>
						</li>
						<li>
							<a href="/vouchers">
								VOUCHERS ATIVOS
							</a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
		