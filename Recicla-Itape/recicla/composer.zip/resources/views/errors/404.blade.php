@extends('.site.template.cabecalho')
@section('cabecalho')
<div class="container-fluid Content404">
	
</div>
@include('site.includes.rodape')
@endsection